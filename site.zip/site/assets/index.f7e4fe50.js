import{i as onMounted,r as resolveComponent,o as openBlock,a as createElementBlock,d as createVNode,b as createBaseVNode,j as createStaticVNode}from"./index.e8f62677.js";const _hoisted_1={class:"doc"},_hoisted_2=createBaseVNode("h1",{id:"coinprice"},"CoinPrice",-1),_hoisted_3=createBaseVNode("p",null,"\u8FD9\u662F\u4E00\u4E2A\u5E01\u4EF7\u683C\u4FE1\u606F\u7EC4\u4EF6",-1),_hoisted_4=createBaseVNode("h2",{id:"\u6F14\u793A"},"\u6F14\u793A",-1),_hoisted_5=createStaticVNode(`<div id="btc" class="m-20"></div><div class="pre-js"><pre><span class="hljs-keyword">const</span> widget = <span class="hljs-keyword">new</span> <span class="hljs-title class_">TokenInsightWidget</span>(<span class="hljs-string">&#39;cec31bc1-b8d9-4c93-8c38-aaf740793101&#39;</span>);
widget.<span class="hljs-title function_">createPrice</span>({
  <span class="hljs-attr">el</span>: <span class="hljs-string">&#39;#btc&#39;</span>,
  <span class="hljs-attr">tid</span>: <span class="hljs-string">&#39;bitcoin&#39;</span>
});</pre></div>`,2),_sfc_main={name:"index",setup(__props){onMounted(()=>{new TokenInsightWidget("cec31bc1-b8d9-4c93-8c38-aaf740793101").createPrice({el:"#btc",tid:"bitcoin"})});const change=newVal=>{const js=`const widget = new TokenInsightWidget('cec31bc1-b8d9-4c93-8c38-aaf740793101');
widget.createPrice({
  el: '#btc',
  tid: 'bitcoin'
});`.replace("bitcoin",newVal);eval(js)};return(e,t)=>{const s=resolveComponent("Colors");return openBlock(),createElementBlock("div",_hoisted_1,[_hoisted_2,_hoisted_3,_hoisted_4,createVNode(s,{onChange:change}),_hoisted_5])}}};export{_sfc_main as default};
