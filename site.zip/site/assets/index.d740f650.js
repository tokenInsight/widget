import{H as e}from"./header.cda85a6e.js";import{o as r,c as o}from"./index.e8f62677.js";const p={name:"index",setup(a){return(t,c)=>(r(),o(e))}};export{p as default};
